﻿namespace Logger.Models.Contracts
{
    public interface ILevelable
    {
        ErrorLevel Level { get; }
    }
}
